<!doctype html>
<html lang="en"><div id="wrapper">
<div id="content"><!--Content area starts here-->
			<div>
				<img src="images/" style="float:left; margin-left:-40px;"/><!-- Begin myContactForm.com Form HTML -->
<form name="contactForm" id="contactForm" method="post"  action="http://www.mycontactform.com/sendform/sendform.php" style="width: 100%; border: 0px solid #000000; margin: 0; padding: 0; background-color: #FFFFFF;">
 
 <div style="background-color: #EFEFEF; border-bottom: 0px solid #D8D8D8; padding: 5px; clear: left; margin: 0;">
  <select name="q1" id="q1" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" required="required"><option value="Bride">Bride</option><option value="Groom">Groom</option></select>
 
 
  <select name="q2" id="q2" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" >
<option value="Afghanistan">Afghanistan</option>
<option value="Albania">Albania</option>

</select>
 
   <select name="q4" id="q4" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" ><option value="20">Select Religion</option><option value="Select Religion">Sikh</option><option value="Hindu">Hindu</option><option value="Jain">Jain</option></select>
 
   <select name="q4" id="q4" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" ><option value="20">20 Yrs</option><option value="28">28</option></select> to 
   <select name="q4" id="q4" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" ><option value="40">40 Yrs</option><option value="28">28</option></select>
 
   <select name="q5" id="q5" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;" ><option value="Aggarwal">Aggarwal</option><option value="Arora">Arora</option></select>
   <select name="q6" id="q6" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #FFFFFF; border: 1px solid #000000; padding: 2px;"  ><option value="Marital Status">Marital Status</option><option value="Married">Married</option><option value="Never Married">Never Married</option></select>
 

   <input name="user" type="hidden" id="user" value="searchpartneronline" />
   <input name="formid" type="hidden" id="formid" value="437964" />
   <input name="subject" type="hidden" id="subject" value="Search Partner Main Form Page" />
   <input name="submit" type="submit" value="Search" style="font-family: Arial; font-size: 16px; color: #000000; background-color: #CCCCCC; border: 2px solid #000000; padding: 2px;" />
</div>
</form>
<!-- End myContactForm.com Form HTML -->
			</div>
			
			<center><h1><a href="http://setfreelancer.com/registeration.php">Click Here for "Free Registeration!"</a></h1></center><br/>
			<center><img src="images/searchpartner-min.jpg"/></center>
			

			
			
			<!-------------------<div id="form2">
			<?php if(isset($_GET['fail'])){
						echo "<script>alert('Email already exist, please try another!')</script>";
					}
					?>
				<form action="insert_user.php" method="post">
										
					<table> 
						<tr>
							<td align="right"><strong>Name:</strong></td>
							<td><input type="text" name="u_name" required="required" placeholder="write your name"/></td>
						</tr>
						
						<tr>
							<td align="right"><strong>Password:</strong></td>
							<td><input type="password" name="u_pass" required="required" placeholder="enter a password"/></td>
						</tr>
						
						<tr>
							<td align="right"><strong>Email:</strong></td>
							<td><input type="email" name="u_email" required="required" placeholder="write your email"/></td>
						</tr>
						
						
						
						
						<tr>
							<td align="right"><strong>Country:</strong></td>
							<td>
								<select name="u_country">
									<option>Select a Country</option>
									<option value="Afghanistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>

								</select>
							</td>
						</tr>
						
						<tr>
							<td align="right"><strong>Gender:</strong></td>
							<td>
								<select name="u_gender">
									<option>Select a Gender</option>
									<option>Male</option>
									<option>Female</option>
								</select>
							</td>
						</tr>
						
						<tr>
							<td align="right"><strong>Brithday:</strong></td>
							<td><input type="date" name="u_birthday" required="required" /></td>
						</tr>
						
						
					
						
						
						
						
						<tr>
							<td colspan="6">
								<button name="sign_up">Sign Up</button>
							</td>
						</tr>
						
					
				</form>
				<tr>
				<td>
				</td>
							<td style="text-align: center;">
								<a href="forgetpassword.php">Forgot Password</a>
							</td>
						</tr>
					</table>
				<?php //include("insert_user.php");
					if(isset($_GET['success'])){
						echo "<h3 style='width:400px; text-align:justify; color:green;'>Hi,'".$_GET['success']."'congratulations, registration is almost complete, please check your email for final verification.</h3>";
					}
					if(isset($_GET['fail'])){
						echo "Registration failed, try again!";
					}
				?>
			</div>--------------------->
			
		</div>
		
		<!--Content area ends here-->
		
		
		</div>