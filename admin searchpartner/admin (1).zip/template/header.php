<!DOCTYPE html> 
<html> 
	<head>
	<style>
	@media only screen and (max-device-width: 480px) {
    .mail_lgn_dv {
      float: none !important; 
    }
    .img_lgn{  float: none !important; 
    }
}
.pass_lgn{
	line-height: 25px;
}
.email_lgn{
line-height: 25px;}
.lgn_dv{width: 173px;float: left;margin-right: 16px;
}
.mail_lgn_dv{
	 float: right; width: 500px;margin-top: 11px;
}
.img_lgn{float:left; }
</style>
		<title>Social Network!</title> 
		<link rel="stylesheet" href="styles/style.css" media="all"/>
		
		<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-107236529-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-107236529-1');
</script>
<meta name="google-site-verification" content="SP2x35-OFV1Dwmnx8NlQNMeJtrFrH5olw7jUsR6DVHA" />


<meta http-equiv="X-UA-compatible" Content="IE-edge"/> 
<meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'/> 
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>





<div id="wrapper">

<!--Header wrapper starts here-->
		<div id="header_wrapper">
		
		
		
		
		
		
		<nav id='menu'> 
<input type=''/> 
 
<li><a href='#'>Search Profile By<font size='1'>&#9660;</font></a> 
<ul class='menus'> 
<li><a href='#'>Religion</a></li> 
<li><a href='#'>Caste</a></li>
<li><a href='#'>Mother Tongue</a></li> 
<li><a href='#'>Occupation</a></li> 
<li><a href='#'>City</a></li> 
<li><a href='#'>State</a></li> 
<li><a href='#'>NRI</a></li> 
<li><a href='#'>Special Cases</a></li>
<li><a href='http://setfreelancer.com/advancesearch.php'>Advance Search</a></li>
<li><a href='http://setfreelancer.com/membershipplan.php'>Membership Plans</a></li>
<li><a href='#'>Contact Us</a></li>
</ul> 
</li> 
<ul> 
<li><a href='/'>Home</a></li> 
 
<li><a href='#'>Search <font size='1'>&#9660;</font></a> 
<ul class='menus'> 
<li><a href='http://setfreelancer.com/matrimonial/advancesearch.php'>Advance Search</a></li> 
<li><a href='http://setfreelancer.com/matrimonial/desiredpartnerprofile.php'>Desired Partner Profile</a></li> 
<li><a href='#'>Search by ID</a></li> 
<li><a href='#'>Tab 4</a></li> 
<li><a href='#'>Tab 5</a></li> 
<li><a href='#'>Tab 6</a></li>
</ul> 
</li> 
<li><a href='#'>Contact</a></li> 
<li><a href='http://setfreelancer.com/matrimonial/membershipplan.php'><font size='1'>&#9660;</font></a> 
<ul class='menus'> 
<li><a href='#'>Tab 1</a></li> 
<li><a href='#'>Tab 2</a></li> 
<li><a href='#'>Tab 3</a></li> 
</ul> 
</li> 
<li><a href='#'>Help</a></li>
<li><a href='#'>Advertise with us</a></li> 
       </ul> 
    </nav>
		
		
		
		
		
		

	</head>
	

<body> 
	
	<!--Container starts here-->
	<div class="container-fluid">
		
			<!--Header starts here-->
			<div id="header">
				<img src="images/matrimonial-min.jpg" height="113px" class="img_lgn"/>
				<form method="post" action="login.php" id="">
				<div class="mail_lgn_dv">
				<div class="lgn_dv">
					<strong>Email:</strong> <br>
					<input type="email" name="email" placeholder="Email" required="required" class="email_lgn">
				</div>
				<div>
					<strong>Password:</strong> <br>
					<input type="password" name="pass" placeholder="****" required="required" class="pass_lgn"> 
				</div>
				<div style="margin-top: 10px; margin-bottom: 10px;"> 
					<button name="login" style="padding: 8px;">Login</button>
					<a href="forgetpassword.php" style="color: white;margin-left: 140px;">Forgot Password</a>
				</div>
					
				</div>	
				</form>
				
			</div>
			
			
			<!--Header ends here-->
		</div>
		<!--Header wrapper ends here-->
		
		</div><!-------Wrapper Ends Here------->