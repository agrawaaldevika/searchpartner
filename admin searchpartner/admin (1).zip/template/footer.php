		<div id="wrapper"><div id="footer">
			<h2>&copy; www.setfreelancer.com</h2> 
			
			
		</div>
	</div>
	<!--Container ends here-->

</body>
</html>