<head>
  
  
  <title>membership plan</title>
  <link href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet"></link>
  <link href="/resources/demos/style.css" rel="stylesheet"></link>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
  </script>
</head><br />
<div dir="ltr" style="text-align: left;" trbidi="on">
<br />
<div id="tabs">
<ul>
<li><a href="#tabs-1">e-Rishta</a></li>
<li><a href="#tabs-2">e-Value</a></li>
<li><a href="#tabs-3">e-Advantage</a></li>
</ul>
<div id="tabs-1">
<h2>eRishta Benefits( Start From ₹ 1,365)</h2><br /><br />
<li>View contacts of members you like<br /></li>
<li>Priority Customer service<br /></li>
<li><strike>Make your contacts visible to others</strike><br /></li>
<li><strike>Profile Boost new</strike><br /></li>
<h2>
<b>Add Astro Compatibility</b></h2><br />


<li>3 months for ₹ 192.50 550<br /></li>
<li>6 months for ₹ 385 1,100<br /></li>
Your Savings ₹ 8125<br />
₹ 4,375 | Pay Now <br />
<b>
<li>3 Months----------------75 Contacts To View-----------------1,365<br /></li>
<strike>3,900</strike><br />
₹ 455/month<br />
<br />
<li>6 Months-------------------125 Contacts To View---------------2,047.50<br /></li>
<strike>5,850 </strike><br />
 ₹ 341.25/month<br />
<br />
<li>Unlimited Months--------------225 Contacts To View--------------3,990<br /></li>
Popular
<strike>11,400</strike></b>


</div>

<br />
<div id="tabs-2">
<h2>eValue Benefits ( Start From ₹ 1,575)</h2><br /><br />
<li>Send Personalized Messages & Chat<br /></li>
<li>View contacts of members you like<br /></li>
<li>Priority Customer service<br /></li>
<li>Make your contacts visible to others<br /></li>
<li><strike>Profile Boost new</strike><br /></li>
<h2>Add Astro Compatibility </h2><br />
<li>3 months for ₹ 192.50 550<br /></li>
<li>6 months for ₹ 385 1,100<br /></li>
Your Savings ₹ 5427.50<br />
₹ 2,922.50 | Pay Now<br />
<b><li>3 Months---------------75 Contacts To View------------------1,575<br /></li>
<strike>4,500</strike><br/>

 ₹ 525/month<br/>
<li>6 Months----------------125 Contacts To View----------------------2,537.50<br /></li>
Popular
<strike>7,250</strike><br/>
 

₹ 422.92/month<br/>


<li>Unlimited Months------------------------225 Contacts To View-----------------------5,775<br /></li>
<strike>16,500</strike></b>

  </div>
<div id="tabs-3">
<h2>eAdvantage Benefits (From ₹ 1,890)</h2><br />
<li>Send Personalized Messages & Chat<br /></li>
<li>View contacts of members you like<br /></li>
<li>Priority Customer service<br /></li>
<li>Make your contacts visible to others<br /></li>
<li>Profile Boost new<br /></li>
<h2>Add Astro Compatibility</h2><br /> 
<li>3 months for ₹ 192.50 550<br /></li>
<li>6 months for ₹ 385 1,100<br /></li>
Your Savings ₹ 11440<br />
₹ 6,160 | Pay Now<br />
<b>
<li>3 Months----------------------------75 Contacts To View----------------------------1,890<br /></li>
<strike>5,400</strike><br />

₹ 630/month<br />
<li>6 Months----------------------------125 Contacts To View-----------------------2,887.50<br /></li>
Popular
<strike>8,250</strike><br />

₹ 481.25/month<br />
<li>Unlimited Months--------------------225 Contacts To View------------------------5,775<br /></li>
<strike>16,500</strike></b>

 
</div>
</div>
</div>
