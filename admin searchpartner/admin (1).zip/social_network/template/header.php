<!DOCTYPE html> 

<html> 
	<head>
		<title>Social Network!</title> 
		<link rel="stylesheet" href="styles/style.css" media="all"/>
	</head>
	

<body> 
	
	<!--Container starts here-->
	<div class="container">
		<!--Header wrapper starts here-->
		<div id="header_wrapper">
			<!--Header starts here-->
			<div id="header">
				<img src="images/" style="float:left;"/>
				<form method="post" action="" id="form1">
					<strong>Email:</strong>
					<input type="email" name="email" placeholder="Email" required="required"/>
					<strong>Password:</strong>
					<input type="password" name="pass" placeholder="****" required="required"/> 
					<button name="login">Login</button>
				</form>
			</div>
			<!--Header ends here-->
		</div>
		<!--Header wrapper ends here-->