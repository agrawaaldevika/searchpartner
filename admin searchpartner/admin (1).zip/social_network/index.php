<?php 
include("template/header.php");
include("template/content.php");
include("template/footer.php");
include("login.php");
?>