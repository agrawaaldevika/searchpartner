<?php 
$con = mysqli_connect("localhost","qwerk","51525354","SOCIALJERSY"); or die("Connection was not established");

?>