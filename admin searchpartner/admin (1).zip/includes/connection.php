<?php 

$con = mysqli_connect("localhost","devika_social","atL2IH@QTkWa","devika_social") or die("Connection was not established");


?>