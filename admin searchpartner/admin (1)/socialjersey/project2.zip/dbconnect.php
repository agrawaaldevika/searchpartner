<?PHP

 
	$servername="160.153.162.18:3306";
    $username = "qwerk";
$password = "aA51525@";
$dbname = "SOCIALJERSY";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 ?>